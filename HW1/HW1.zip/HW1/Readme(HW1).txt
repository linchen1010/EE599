Q6-Factorial

After running Bazel run src/main:main
The program will request to input a value which is n
Then the program will output n! (For both recursive and non-recursive method)

For example
>> input n = 5
>> output 5! = 120
>> input n = 0
>> output 0! = 1
>> input n = -1
>> output >> n should be greater than or equal zero

Note: Input n can't be too large, the value will overflow