#include "solution.h"

std::string Solution::PrintMyName() { 
  return "Name: Chun-Hao Lai / Email: laichunh@usc.edu"; 
}

