#include <iostream>
#include "src/lib/solution.h"

int main()
{
    Solution solution ;
    std::cout << solution.PrintMyName() << std::endl;

    return EXIT_SUCCESS;
}